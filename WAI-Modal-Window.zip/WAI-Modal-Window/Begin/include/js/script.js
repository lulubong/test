/* script.js - 스크립트, 2012 © yamoo9.com
---------------------------------------------------------------- */
;(function($, undefined){
$(function($) {

// load - 모달 윈도우


// click - 모달 윈도우



// 스킵 내비게이션
$('#skip-navigation a').on('click', function(e) {
	e.preventDefault();
	var target_id = this.getAttribute('href');

	$(target_id)
		.attr('tabindex', 0)
		.focus()
		.on('blur', function() {
			this.setAttribute('tabindex', '-1');
		});
});

});	
})(window.jQuery);