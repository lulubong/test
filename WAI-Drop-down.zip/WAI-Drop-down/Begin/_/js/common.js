// 안전한 프로그래밍을 위해 독립적인 공간 설정
(function(win, doc, html, body, $, undefined ){
"use strict"; // 엄격한 문법 모드 발동

})(window, document, document.documentElement, document.body, window.jQuery);