(function(win, doc, html, body, $, undefined ){
"use strict";


})(window, document, document.documentElement, document.body, window.jQuery);